<html> 
    <head> 
     
            <a href="<?php echo base_url(); ?>" class="logo"></a>
            <ul>
               <li><a href="<?php echo base_url(); ?>hlavni">Úvod</a></li>
               
                 <li><a href="<?php echo base_url(); ?>mesto">Města</a></li>
                  <li><a href="<?php echo base_url(); ?>obor">Obor</a></li>
                  <li><a href="<?php echo base_url(); ?>pocet">Počet</a></li>
            </ul>
    
      <meta charset = "utf-8"> 
      
      <style >
          ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
          
          table{
              color:blue;
              border: 8px solid red;
          }
          
          
          
      </style>
      
      
   </head>
<body>
        <
</body>
</html>